// Katherine Parks
// Fall 2022
// CSE 3310

package uta.cse3310;

import java.util.ArrayList;

public class BlackJack 
{
    public static void main(String[] args) 
    {  
        
    }  

    public void startGame(Player listOfPlayers)
    {

    }

    public void startNewGame(Player listOfPlayers, ArrayList<Card> deck)
    {
            
    }
}