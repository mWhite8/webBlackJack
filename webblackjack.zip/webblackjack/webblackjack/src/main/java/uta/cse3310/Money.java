package uta.cse3310;

public class Money extends Players
{
    public void displayCash()
    {

    }

    public void bet(Player player)
    {
        
    }
}
