package uta.cse3310;

import java.util.ArrayList;

public class Hints 
{
    ArrayList<String> hints;
    
    public String displayHint()
    {
        //placeholder until functionality is added
        String hint = null;
        return hint;
    }
}
