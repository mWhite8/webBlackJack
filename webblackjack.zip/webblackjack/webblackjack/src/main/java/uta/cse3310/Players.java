package uta.cse3310;

public class Players extends Player
{
    Player listOfPlayers;
    int numberOfPlayers;
    int numBots;

    public Boolean playerCount()
    {
        //placeholder until functionality is added
        return false;
    }
}
