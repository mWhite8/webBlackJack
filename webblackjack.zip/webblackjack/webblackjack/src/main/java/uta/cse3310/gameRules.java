package uta.cse3310;

public class gameRules 
{
    enum rules{};    
}
