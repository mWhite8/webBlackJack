package uta.cse3310;

import java.util.ArrayList;

public class Deck extends Card
{
    int hearts = 13;
    int spades = 13;
    int clovers = 13;
    int diamonds = 13;
    ArrayList<Card> deck;
    int totalcards;

    public void shuffle(ArrayList<Card> deck)
    {

    }

    public void nextCardDisplay(ArrayList<Card> deck)
    {

    }

    public Card getRandom()
    {
        //placeholder until functionality is added
        Card card = null;
        return card;
    }
}
