package uta.cse3310;

public class Bots extends Hand
{
    Hand hand;
    String behavior;
    double balance = 200;
    boolean in;

    public void riskLevel(String behavior)
    {

    }

    public Hand getHand()
    {
        return hand;
    }
}
