package uta.cse3310;

import java.util.ArrayList;

public class pointCount 
{
    public void Winner(ArrayList<Player> listOfPlayers, ArrayList<Card> deck)
    {

    }
}
