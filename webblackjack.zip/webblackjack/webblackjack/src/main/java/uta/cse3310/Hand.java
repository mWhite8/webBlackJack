package uta.cse3310;

import java.util.ArrayList;

public class Hand extends Card
{
    ArrayList<Card> cards;
    int totalVal;

    public int getVal()
    {
        return totalVal;
    }

    public void updateDeck(ArrayList<Card> deck)
    {
        
    }
}
