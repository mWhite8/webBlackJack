package uta.cse3310;

public class Dealer
{
    Hand dealerHand;
    double netMoney;

    public double tenProbability()
    {
        //placeholder until functionality is added
        double prob = 0;
        return prob;
    }

}
