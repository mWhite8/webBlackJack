package uta.cse3310;

public class Card 
{
    int value;
    String Suite;

    public int getValue() 
    {
        return value;
    }
}
